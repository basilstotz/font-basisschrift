# Defaults for font-basisschrift initscript
# sourced by /etc/init.d/font-basisschrift
# installed at /etc/default/font-basisschrift by the maintainer scripts

#
# This is a POSIX shell fragment
#

# Additional options that are passed to the Daemon.
DAEMON_OPTS=""
