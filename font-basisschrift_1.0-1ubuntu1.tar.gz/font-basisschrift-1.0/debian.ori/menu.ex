?package(font-basisschrift):needs="X11|text|vc|wm" section="Applications/see-menu-manual"\
  title="font-basisschrift" command="/usr/bin/font-basisschrift"
